.. Python Cookbook documentation master file, created by
   sphinx-quickstart on Tue Feb 10 13:33:42 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

欢迎来到 Python 菜谱的主页
===========================================

ActiveState 上有很多用户提供的 Python 代码，这些代码能够完成固定的任务；

O’Reilly 根据这些资料出版过一本《Python Cookbook》，但是这本书上并没有列出所有有用的代码。

因此，这里为用户收集一些有用的功能的 Python 代码，为用户提供方便。

activestate 原地址为： http://code.activestate.com/recipes/langs/python/。

希望大家能在这里找到想要的东西！

.. toctree::
   :maxdepth: 2

   cookbook_1
   cookbook_2
   cookbook_3
   cookbook_4
   cookbook_5
   cookbook_6
   cookbook_7
   cookbook_8
   cookbook_9
   cookbook_10
   cookbook_11
   cookbook_12
   cookbook_13
   cookbook_14



