Python Cookbook（Python 菜谱）
=================================

ActiveState 上有很多用户提供的 Python 代码，这些代码能够完成固定的任务；

O’Reilly 根据这些资料出版过一本《Python Cookbook》，但是这本书上并没有列出所有有用的代码。

因此，这里为用户收集一些有用的功能的 Python 代码，为用户提供方便。activestate 原地址为： http://code.activestate.com/recipes/langs/python/。

更多的信息请访问 
